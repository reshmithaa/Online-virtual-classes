import os
import mysql.connector as msq
name=str(input("enter mysql username : "))
p=str(input("enter password : "))
folder="virtual_class"

mycon = msq.connect(host="localhost", user=name, passwd=p)
cur=mycon.cursor()
cur.execute("create database classroom")
cur.execute("create database data")
cur.execute("create database attendance")
mycon.commit()

mydb = msq.connect(host="localhost", user=name, passwd=p,database="classroom")
curs=mydb.cursor()
curs.execute("create table clsinfo(clsname varchar(20),tpassword varchar(7) PRIMARY KEY,cpassword varchar(7),nsub varchar(2))")
mydb.commit()

mydbd = msq.connect(host="localhost", user=name, passwd=p,database="data")
curs=mydbd.cursor()
curs.execute("create table tab1(username varchar(20) PRIMARY KEY,password varchar(8),mno varchar(10))")
mydbd.commit()

vc='''from tkinter import*
from tkinter import ttk
from PIL import ImageTk,Image
from pack import logcre

root=Tk()
root.geometry("450x600+450+75")
root.title("Online Virtual Classes")
root.resizable(0,0)
root.iconbitmap("icon.ico")

img=ImageTk.PhotoImage(Image.open("in.png"))
lab=Label(root,image=img)
lab.grid(row=0,column=0,columnspan=3)

b=ttk.Button(root,text="LOGIN",command=lambda:logcre.login(root))
b.place(x=350,y=90)
b2=ttk.Button(root,text="SIGNUP",command=lambda :logcre.create(root))
b2.place(x=260,y=90)

root.mainloop()'''

cs='''from tkinter import *
from PIL import ImageTk , Image
from tkinter import messagebox
import mysql.connector as msq
from pack import teacher,editcls

mycon = msq.connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="classroom")
mycona = msq.connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="attendance")
def clsreg(entry1,entry2,entry3,root):
    e1=entry1.get()
    e2=entry2.get()
    e3=entry3.get()
    mycursor = mycon.cursor()

    if len(e2) != 7 or e2 == "        " or len(e3) != 7 or e3 == "        ":
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("Online Virtual Classes", "passwords must have 7 charecters")
        teacher.create(root)
    elif len(e1) > 15 or len(e1) < 4:
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("username error", "Classroom name should contain 4 charecters and not exceed 15 charecters")
        teacher.create(root)
    else:
        mycursor.execute("select * from clsinfo")
        result = mycursor.fetchall()
        for i in result:
            if i[1] == e2 or i[2]==e3:
                ii = Tk()
                ii.withdraw()
                messagebox.showerror("Online Virtual Classes", "Enter another password")
                teacher.create(root)

        sql = "INSERT INTO clsinfo(clsname,tpassword,cpassword) VALUES (%s,%s,%s)"
        val = (e1,e2,e3)
        mycursor.execute(sql, val)
        q="create table "+e2+"(subject varchar(20),starttime varchar(10),endtime varchar(10),livelink varchar(100),reclink varchar(100),fa varchar(7))"

        mycursor.execute(q)
        mycon.commit()
        cursor=mycona.cursor()
        qq="create table "+e2+"(mno varchar(10))"
        qqq = "create table " + e2+"ha" + "(date varchar(10),time varchar(10),username varchar(20),mno varchar(10),reason varchar(50))"
        cursor.execute(qqq)
        cursor.execute(qq)
        ii = Tk()
        ii.withdraw()
        messagebox.showinfo("Online Virtual Classes", "SUCESSFULLY record registered")
        #crt.destroy()
        editcls.berforenan(root,entry2)

def clsdel(e11,e22):
    mycursor = mycon.cursor()
    mycursor.execute("select * from clsinfo")
    result = mycursor.fetchall()
    for i in result:
        if i[0] == e11 and i[1] == e22:
            tab=str(i[1])

            qu="select * from "+tab
            mycursor.execute(qu)
            res=mycursor.fetchall()
            for rec in res:
                #ha=rec[5]
                fa=rec[5]
                myocursor = mycona.cursor()
                #que="drop table "+ha
                quer="drop table "+fa
                #myocursor.execute(que)
                myocursor.execute(quer)

            sql = "delete from clsinfo where tpassword='%s'"%(e22,)
            mycursor.execute(sql)
            q="drop table "+tab
            mycursor.execute(q)
            mycon.commit()

            mycursor=mycona.cursor()
            qq="drop table "+tab
            que="drop table "+tab+"ha"
            mycursor.execute(que)
            mycursor.execute(qq)
            mycona.commit()

            ii = Tk()
            ii.withdraw()
            messagebox.showinfo("Online Virtual Classes", "Classroom deleted sucessfully")'''

ed='''from tkinter import *
from tkinter import messagebox,ttk
import mysql.connector as msq
from pack import teacher,logcre
import webbrowser
import random,string

mydb=msq.connect(host="localhost", user="'''+name+'''",passwd="'''+p+'''",database="classroom")
mydba=msq.connect(host="localhost", user="'''+name+'''",passwd="'''+p+'''",database="attendance")
tab=0


def edit(root):
    logcre.clear(root)

    frame1=LabelFrame(root,borderwidth=5)
    frame1.pack(padx=10,pady=100)
    laba=Label(frame1,text="   Edit Classroom   ",font=("Helvetica",15))
    laba.pack()

    labela = Label(root, text="Classroom name", font=("arial", 15))
    labela.place(x=20, y=200)
    entera = Entry(root, bd=5, width=35)
    entera.place(x=210, y=200)

    labelb = Label(root, text="Teacher's Password", font=("arial", 15))
    labelb.place(x=18, y=240)
    enterb = Entry(root, bd=5, width=35)
    enterb.place(x=210, y=240)

    cd = Button(root, text="Next", padx=100, pady=15, font=("arial", 12), bg="sky blue", fg="black", command=lambda :next(entera,enterb,root))
    cd.place(x=100, y=500)
    bac=Button(root,text="Back",padx=8,pady=2,font=("arial",12),bg="sky blue",command=lambda :teacher.back(root))
    bac.place(x=10,y=5)

def next(entera, enterb, ma):
    mycursor = mydb.cursor()
    f = "select * from clsinfo"
    mycursor.execute(f)
    a = mycursor.fetchall()
    l = mycursor.rowcount
    pp = str(entera.get())
    qq = str(enterb.get())
    if len(qq) != 7:
        abcd= Tk()
        abcd.withdraw()
        messagebox.showerror("ERROR", "Password must contain 7 digits")
    for i in a:
        if i[0] == pp and i[1] == qq:
            ii = Tk()
            ii.withdraw()
            messagebox.showinfo("Info", "classroom found")
            global tab
            tab = str(i[1])
            nan(ma)


def berforenan(root,tname):
    global tab
    tab=tname.get()
    nan(root)

def nan(root):
    logcre.clear(root)
    mycon = msq.Connect(host="localhost", user="root", passwd="rrrr1111", database="classroom")
    cursor = mycon.cursor()
    q = "select * from " + tab
    cursor.execute(q)
    i = 0
    sum = Label(root, text="Subjects", font=("Helvetica", 15))
    sum.place(x=180, y=16)
    frame = LabelFrame(root, borderwidth=5)
    frame.pack(padx=10, pady=80)
    for student in cursor:
        # print(student)
        for j in range(1):
            name = student[j]
            lab = Button(frame, text=name, padx=50, pady=5, font=("Helvetica", 12),
                         command=lambda name=name: sub(name, root))
            lab.grid(row=i + 1, column=j)
            deleteBtn = Button(frame, text='Delete Subject', command=lambda name=name: delrec(name,root))
            deleteBtn.grid(row=i+1, column=j+1, padx=10)
        i = i + 1
    bac = Button(root, text="Back", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: edit(root))
    bac.place(x=10, y=15)
    addb = Button(root, text="Add", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: add(root))
    addb.place(x=370, y=15)
    blk = Button(root, text="Block", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: block(root))
    blk.place(x=10, y=500)
    unblk = Button(root, text="Unblock", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: unblock(root))
    unblk.place(x=350, y=500)
    half = Button(root, text="Half Attendance", padx=8, pady=2, font=("arial", 12), bg="sky blue",
                  command=lambda: viewhalf(root))
    half.place(x=150, y=500)

def block(root):
    logcre.clear(root)

    labela = Label(root, text="MOBILE NO. : ", font=("arial", 15))
    labela.place(x=20, y=200)
    entera = Entry(root, bd=5, width=35)
    entera.place(x=210, y=200)
    ok = Button(root, text="BLOCK", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: okblock(entera))
    ok.place(x=350, y=500)
    back = Button(root, text="Back", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: nan(root))
    back.place(x=10, y=10)

def okblock(entera):
    ent=str(entera.get())
    if ent.isdigit() == True and len(ent)==10:
        cursor=mydba.cursor()
        qu="insert into "+str(tab)+" values(%s)"%(ent,)
        cursor.execute(qu)
        mydba.commit()
        messagebox.showinfo("Online Virtual Classes","Sucessfully Mobile no. is blocked")
    else:
        messagebox.showerror("Online Virtual Classes", "INVALID MOBILE NO.")

def unblock(root):
    logcre.clear(root)

    labela = Label(root, text="MOBILE NO. : ", font=("arial", 15))
    labela.place(x=20, y=200)
    entera = Entry(root, bd=5, width=35)
    entera.place(x=210, y=200)
    ok = Button(root, text="UNBLOCK", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: okunblock(entera))
    ok.place(x=330, y=500)
    back = Button(root, text="Back", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: nan(root))
    back.place(x=10, y=10)

def okunblock(entera):
    ent = str(entera.get())
    if ent.isdigit()==True and len(ent)==10:
        cursor = mydba.cursor()
        qu = "delete from " + str(tab) + " where mno=%s" % (ent,)
        cursor.execute(qu)
        mydba.commit()
        messagebox.showinfo("Online Virtual Classes", "Sucessfully Mobile no. is unblocked")
    else:
        messagebox.showerror("Online Virtual Classes", "INVALID MOBILE NO.")

def delrec(name,root):
    mycursor = mydb.cursor()
    mycursor.execute("select * from "+str(tab))
    result = mycursor.fetchall()
    for student in result:
        print(student[0])
        if name==student[0]:
            #ha=str(student[5])
            fa=str(student[5])
            cursor = mydba.cursor()
            #qq = "drop table " + ha
            qqq = "drop table " + fa
            #cursor.execute(qq)
            cursor.execute(qqq)
            mydba.commit()

    q='delete from '+str(tab)+' where subject="'+str(name)+'"'
    print(q)
    mycursor.execute(q)
    mydb.commit()

    nan(root)

def add(root):
    logcre.clear(root)

    label6 = Label(root, text="Subject name", font=("arial", 15))
    label6.place(x=10, y=150)
    entry5 = Entry(root, bd=5)
    entry5.place(x=235, y=150, width=200)

    label7 = Label(root, text="Enter Start Time", font=("arial", 15))
    label7.place(x=10, y=190)
    entry6 = Entry(root, bd=5)
    entry6.place(x=235, y=190, width=200)

    label18 = Label(root, text="Enter End Time", font=("arial", 15))
    label18.place(x=10, y=230)
    entry17 = Entry(root, bd=5)
    entry17.place(x=235, y=230, width=200)

    label8 = Label(root, text="Live Session Link", font=("arial", 15))
    label8.place(x=10, y=270)
    entry7 = Entry(root, bd=5)
    entry7.place(x=235, y=270, width=200)

    label9 = Label(root, text="Recorded session link", font=("arial", 15))
    label9.place(x=10, y=310)
    entry8 = Entry(root, bd=5)
    entry8.place(x=235, y=310, width=200)

    okb = Button(root, text="Done", padx=30, pady=5, borderwidth=4, font=("arial", 12), bg="sky blue",
                 command=lambda: save(root,entry5,entry6,entry17,entry7,entry8))
    okb.place(x=100, y=400)
    bac = Button(root, text="Back", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: nan(root))
    bac.place(x=10, y=35)

def get_random_string(length):
    # Random string with the combination of lower and upper case
    letters = string.ascii_letters
    result_str = ''.join(random.choice(letters) for i in range(length))
    result_str=result_str.lower()
    #print("Random string is:", result_str)
    return result_str

def save(root,e1,e2,e3,e4,e5):
    e1 = str(e1.get())
    e2 = str(e2.get())
    e3 = str(e3.get())
    e4 = str(e4.get())
    e5 = str(e5.get())
    epp = str(get_random_string(5))
    #e6 = epp+"ha"
    e7 = epp+"fa"
    #e6.strip()
    e7.strip()
    print(e7)

    cursor = mydb.cursor()
    q="INSERT INTO "+str(tab)+"(subject,starttime,endtime,livelink,reclink,fa) VALUES (%s,%s,%s,%s,%s,%s)"
    val=(e1,e2,e3,e4,e5,e7)

    mycursor=mydba.cursor()
    #qq="create table "+e6+"(date varchar(10),time varchar(10),username varchar(20),mno varchar(10),reason varchar(50))"
    qqq="create table "+e7+"(date varchar(10),username varchar(20),mno varchar(10))"
    print(qqq)
    #mycursor.execute(qq)
    mycursor.execute(qqq)
    mydba.commit()

    print(q)
    cursor.execute(q,val)
    mydb.commit()
    nan(root)

def okay(root,e1,e2,e3,e4,e5,name):
    e1=e1.get()
    e2=e2.get()
    e3=e3.get()
    e4=e4.get()
    e5=e5.get()

    cursor = mydb.cursor()
    q = 'update '+tab+' set subject="'+e1+'",starttime="'+e2+'",endtime="'+e3+'",livelink="'+e4+'",reclink="'+e5+'" where subject="'+name+'"'
    print(q)
    cursor.execute(q)
    mydb.commit()

    nan(root)

    #save(ra,e1,e2,e3,e4,e5)

def sub(name, root):
    logcre.clear(root)
    cursor = mydb.cursor()
    q = "select * from " + tab
    cursor.execute(q)
    for student in cursor:
        if str(student[0])==str(name):
            e1 = str(student[0])
            e2 = str(student[1])
            e3  =str(student[2])
            e4 = str(student[3])
            e5 = str(student[4])

    label6 = Label(root, text="Subject name", font=("arial", 15))
    label6.place(x=10, y=150)
    entry5 = Entry(root, bd=5)
    entry5.place(x=235, y=150, width=200)
    entry5.insert(0,e1)

    label7 = Label(root, text="Enter Start Time", font=("arial", 15))
    label7.place(x=10, y=190)
    entry6 = Entry(root, bd=5)
    entry6.place(x=235, y=190, width=200)
    entry6.insert(0, e2)

    label18 = Label(root, text="Enter End Time", font=("arial", 15))
    label18.place(x=10, y=230)
    entry17 = Entry(root, bd=5)
    entry17.place(x=235, y=230, width=200)
    entry17.insert(0, e3)

    label8 = Label(root, text="Live Session Link", font=("arial", 15))
    label8.place(x=10, y=270)
    entry7 = Entry(root, bd=5)
    entry7.place(x=235, y=270, width=200)
    entry7.insert(0, e4)

    label9 = Label(root, text="Recorded session link", font=("arial", 15))
    label9.place(x=10, y=310)
    entry8 = Entry(root, bd=5)
    entry8.place(x=235, y=310, width=200)
    entry8.insert(0, e5)

    okl = Button(root, text="OK", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: okay(root,entry5,entry6,entry17,entry7,entry8,name))
    okl.place(x=350, y=500)
    bac = Button(root, text="Back", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: nan(root))
    bac.place(x=10, y=5)
    can = Button(root, text="Cancel", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: nan(root))
    can.place(x=50, y=500)

    full = Button(root, text="Attendance", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: viewfull(root,name))
    full.place(x=190, y=500)

def viewfull(root,name):
    mydba = msq.connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="attendance")
    logcre.clear(root)

    main = LabelFrame(root)
    main.pack(padx=20, pady=90, fill=BOTH, expand=1)
    can = Canvas(main)
    can.pack(side=LEFT, fill=BOTH, expand=1)

    scroll = ttk.Scrollbar(main, orient=HORIZONTAL, command=can.xview)
    scroll.pack(side=BOTTOM, fill=X)

    scroll = ttk.Scrollbar(main, orient=VERTICAL, command=can.yview)
    scroll.pack(side=RIGHT, fill=Y)

    can.configure(yscrollcommand=scroll.set)
    can.bind('<Configure>', lambda e: can.configure(scrollregion=can.bbox("all")))

    global frame
    frame = LabelFrame(can, borderwidth=5)
    frame.pack(padx=10, pady=150)
    can.create_window((10, 80), window=frame, anchor="nw")

    frame1 = Frame(root, borderwidth=5)
    frame1.pack(padx=10, pady=50)
    lab = Label(root, text="Attendance : " + str(name), font=("arial", 15))
    lab.place(x=110, y=10)
    cursor=mydb.cursor()
    cursor.execute("select * from "+str(tab))
    result = cursor.fetchall()
    for i in result:
        if name == i[0]:
            fa=i[5]
            mycursor=mydba.cursor()
            mycursor.execute("select * from "+fa)
            rec=mycursor.fetchall()
            ii=0
            for i in rec:
                for j in range(2):
                    bab = Label(frame, text=i[0], padx=50, pady=5, font=("Helvetica", 12), borderwidth=0)
                    bab.grid(row=ii + 1, column=0)
                    lab = Label(frame, text=i[1], padx=50, pady=5, font=("Helvetica", 12))
                    lab.grid(row=ii + 1, column=1)
                    lab1 = Label(frame, text=i[2], padx=50, pady=5, font=("Helvetica", 12))
                    lab1.grid(row=ii + 1, column=2)
                ii+=ii

    back=Button(root,text="Back",bg="sky blue",font=("arial", 12),command=lambda :sub(name,root))
    back.place(x=10,y=5)

    clel = Button(root, text="Clear All",font=("arial", 12),bg="sky blue", command=lambda: clearf(fa))
    clel.place(x=200, y=500)

    def clearf(fa):
        mydba = msq.connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="attendance")
        mycursor = mydba.cursor()
        mycursor.execute("select * from " + fa)
        rec = mycursor.fetchall()
        ii = 0
        for i in rec:
            q = "delete from " + fa + " where username='" + i[1] + "'"
            mycursor.execute(q)
        mydba.commit()
        viewfull(root,name)


def viewhalf(root):
    mydba = msq.connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="attendance")
    logcre.clear(root)

    ha=str(tab)+"ha"

    main = LabelFrame(root)
    main.pack(padx=20, pady=90, fill=BOTH, expand=1)

    can = Canvas(main)
    can.pack(side=LEFT, fill=BOTH, expand=1)

    scroll = ttk.Scrollbar(main, orient=HORIZONTAL, command=can.xview)
    scroll.pack(side=BOTTOM, fill=X)

    can.configure(yscrollcommand=scroll.set)
    can.bind('<Configure>', lambda e: can.configure(scrollregion=can.bbox("all")))

    scroll = ttk.Scrollbar(main, orient=VERTICAL, command=can.yview)
    scroll.pack(side=RIGHT, fill=Y)

    can.configure(yscrollcommand=scroll.set)
    can.bind('<Configure>', lambda e: can.configure(scrollregion=can.bbox("all")))

    global frame
    frame = LabelFrame(can, borderwidth=5)
    frame.pack(padx=10, pady=150)
    can.create_window((10, 80), window=frame, anchor="nw")

    frame2 = LabelFrame(root, borderwidth=5)
    frame2.pack(padx=10, pady=50)
    lab = Label(root, text="Attendance",font=("arial", 15))
    lab.place(x=200, y=10)
    cursor = mydba.cursor()
    cursor.execute("select * from " + str(tab)+"ha")
    result = cursor.fetchall()
    ii=0
    for i in result:
        for j in range(5):
            bab = Label(frame, text=i[2], padx=10, pady=5, font=("Helvetica", 12), borderwidth=0)
            bab.grid(row=ii + 1, column=0)

            lab = Label(frame, text=i[3], padx=10, pady=5, font=("Helvetica", 12))
            lab.grid(row=ii + 1, column=1)

            bab = Label(frame, text=i[4], padx=10, pady=5, font=("Helvetica", 12), borderwidth=0)
            bab.grid(row=ii + 1, column=3)

            lab = Label(frame, text=i[0], padx=10, pady=5, font=("Helvetica", 12))
            lab.grid(row=ii + 1, column=4)

            lab = Label(frame, text=i[1], padx=10, pady=5, font=("Helvetica", 12))
            lab.grid(row=ii + 1, column=5)
        ii+=1

    back = Button(root, text="Back",bg="sky blue",font=("arial", 12), command=lambda :nan(root))
    back.place(x=10, y=5)

    clel = Button(root, text="Clear All",bg="sky blue",font=("arial", 12), command=lambda :clear(ha))
    clel.place(x=200, y=500)

    def clear(fa):
        mydba = msq.connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="attendance")
        mycursor = mydba.cursor()
        mycursor.execute("select * from " + fa)
        rec = mycursor.fetchall()
        ii = 0
        for i in rec:
            q = "delete from " + fa + " where username='" + i[2] + "'"
            mycursor.execute(q)
        mydba.commit()
        viewhalf(root)

def check(root,e1,e2):
    e1=e1.get()
    e2=e2.get()
    mycursor = mydb.cursor()
    if len(e2) != 7 or e2 == "        ":
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("Online Virtual Classes", "password must have 7 charecters")
    elif len(e1) > 15 or len(e1) < 4:
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("username error", "username should contain 4 charecters and not exceed 15 charecters")
    else:
        mycursor.execute("select * from clsinfo")
        result = mycursor.fetchall()
        for i in result:
            if i[0] == e1 and i[1]==e2:
                mydb.commit()
                ii = Tk()
                ii.withdraw()
                messagebox.showinfo("Online Virtual Classes", "Connecting to classroom")
                global tname
                tname=str(i[1])
                print(tname)
               # sturoot.destroy()
                teaentry(root,tname)


def teaentry(root,tname):
    logcre.clear(root)
    print(tab,tname)
    cursor = mydb.cursor()
    q = "select * from " + tname
    cursor.execute(q)
    i = 0
    sum = Label(root, text="Class room time table", font=("Helvetica", 15))
    sum.place(x=130, y=36)
    frame = LabelFrame(root, borderwidth=5)
    frame.pack(padx=10, pady=80)
    for student in cursor:
        # print(student)
        for j in range(2):
            name = student[0]
            lab = Button(frame, text=name, padx=30, pady=5, font=("Helvetica", 12),
                         command=lambda name=name: sur(name))
            lab.grid(row=i + 1, column=0)

            la=Label(frame,text=student[1],padx=30, pady=5, font=("Helvetica", 12))
            la.grid(row=i+1,column=1)
            lab1 = Label(frame, text=student[2], padx=30, pady=5, font=("Helvetica", 12))
            lab1.grid(row=i + 1, column=2)

        i = i + 1
    bac = Button(root, text="Back", padx=8, pady=2, font=("arial", 12), bg="sky blue", command=lambda: teacher.back(root))
    bac.place(x=10, y=35)

def sur(name):
    cursor=mydb.cursor()
    q = "select * from " + tab
    cursor.execute(q)
    for rec in cursor:
        #print(rec,name)
        if name == rec[0]:
            webbrowser.open_new(str(rec[3]))
'''
fo='''from tkinter import*
import tkinter.font as font
from tkinter import ttk,messagebox
from PIL import ImageTk , Image
from pack import logcre,mode1
import mysql.connector as msq

mycon = msq.connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="data")
roo=0
mn=0
b=""
c=""
def forgot(root):
    logcre.clear(root)
    mycursor = mycon.cursor()

    frame=LabelFrame(root,text="Enter Mobile Number")
    frame.pack(padx=0,pady=100)

    frame1=LabelFrame(root,text="Update Info",borderwidth=0,padx=10,pady=5)
    frame1.pack(padx=0,pady=20)

    frame2=LabelFrame(root,borderwidth=10)
    frame2.pack()

    def okf():
        global mn
        mn = str(mno.get())
        if len(mn) != 10 or mn.isdigit() == False:
            ii = Tk()
            ii.withdraw()
            messagebox.showerror("Online Virtual Classes", "INVALID MOBILE NUMBER")
        else:
            mycursor.execute("select * from tab1")
            result = mycursor.fetchall()
            for i in result:
                if i[2] == mn:
                    mycon.commit()
                    ii = Tk()
                    ii.withdraw()
                    messagebox.showinfo("Online Virtual Classes", "Account found")
                    updatebtn = ttk.Button(frame2, text="Update Account",command=updatef)
                    updatebtn.grid(row=2, column=0, columnspan=2)
                    global c
                    c="ok"
            if c!="ok":
                ii = Tk()
                ii.withdraw()
                messagebox.showerror("Online Virtual Classes", "Account not found")

    def updatef():

        un = str(username.get())
        pw = str(password.get())

        mycursor.execute("select * from tab1")
        result = mycursor.fetchall()
        for i in result:
            if i[2] == mn:
                sql = "update tab1 set username='%s',password='%s' where mno='%s'" % (un, pw, mn)
                mycursor.execute(sql)
                mycon.commit()
                messagebox.showinfo("Online Virtual Classes", "Account sucessfully updated")
                mode1.ask(root)
                global b
                b = "ok"
        if b != "ok":
            ii = Tk()
            ii.withdraw()
            messagebox.showerror("Password Manager", "Account not found")

    mnoLabel = Label(frame, text="Mobile No.")
    mnoLabel.grid(row=0, column=0)
    mno = Entry(frame, width=35, borderwidth=3)
    mno.grid(row=0, column=1, columnspan=2)
    okbtn=ttk.Button(frame,text="OK",command=okf)
    okbtn.grid(row=1,column=0,columnspan=3)

    backb = ttk.Button(root, text="Back",command=lambda:logcre.login(root))
    backb.place(x=5,y=5)

    usernameLabel = Label(frame1, text="User Name").grid(row=0, column=0)
    username = Entry(frame1, width=35, borderwidth=3)
    username.grid(row=0, column=1, columnspan=2)

    passwordLabel = Label(frame1, text="Password").grid(row=1, column=0)
    password = Entry(frame1, width=35, borderwidth=3, show='*')
    password.grid(row=1, column=1)

    updatebtn=ttk.Button(frame2,text="Update Account",state=DISABLED)
    updatebtn.grid(row=2,column=0,columnspan=2)

    myfnt = font.Font(family='Helvetica', size=15, weight='bold')
    mnoLabel['font']=myfnt'''


log='''from tkinter import*
from tkinter import ttk,messagebox
from PIL import ImageTk,Image
import mysql.connector as msq
import pack.forgot
from pack import mode1

mycon = msq.connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="data")

l=""

def clear(top):
    for i in top.winfo_children():
        i.destroy()

def home(root):
    clear(root)
    global img,lab
    img = ImageTk.PhotoImage(Image.open("in.png"))
    lab = Label(root, image=img)
    lab.grid(row=0, column=0, columnspan=3)

    b = ttk.Button(root, text="LOGIN", command=lambda: login(root))
    b.place(x=350, y=90)
    b2 = ttk.Button(root, text="SIGNUP", command=lambda: create(root))
    b2.place(x=260, y=90)

def create(root):
    clear(root)

    frame1=LabelFrame(root,borderwidth=5)
    frame1.pack(padx=10,pady=100)
    laba=Label(frame1,text="      SIGNUP-PAGE      ",font=("Helvetica",15)).pack()

    global username
    global password
    usernameLabel = Label(root, text="User Name : ",font=("arial",15)).place(x=50.,y=200)
    username = Entry(root, width=35, borderwidth=3)
    username.place(x=200,y=200)

    passwordLabel = Label(root, text="Password : ",font=("arial",15)).place(x=50,y=240)
    password = Entry(root, width=35, borderwidth=3, show='*')
    password.place(x=200,y=240)

    mnoLabel = Label(root, text="Mobile No.",font=("arial",15)).place(x=50,y=280)
    mno = Entry(root, width=35, borderwidth=3)
    mno.place(x=200,y=280)

    loginButton = ttk.Button(root, text="Create Account", command=lambda: clickcre(root,username, password,mno))
    loginButton.place(x=320,y=330)
    backButton = ttk.Button(root, text="Login Page", command=lambda:login(root))
    backButton.place(x=60,y=330)

def login(root):
    global ro
    clear(root)

    frame1=LabelFrame(root,borderwidth=5)
    frame1.pack(padx=10,pady=100)
    laba=Label(frame1,text="      LOGIN PAGE      ",font=("Helvetica",15)).pack()

    loginButton = ttk.Button(root, text="Login" ,command=lambda:clicklogin(root,username,password))
    loginButton.place(x=330.,y=300)
    forgotButton = ttk.Button(root, text="Forgot Password", command=lambda :pack.forgot.forgot(root))
    forgotButton.place(x=50,y=300)
    creButton = ttk.Button(root, text="Signup Page", command=lambda :create(root))
    creButton.place(x=200,y=300)


    global username
    global password
    usernameLabel = Label(root, text="User Name",font=("Helvetica",15)).place(x=50.,y=200)
    username = Entry(root,width=35,borderwidth=4)
    username.place(x=200.,y=200)

    passwordLabel = Label(root,text="Password",font=("Helvetica",15)).place(x=50.,y=240)
    password = Entry(root,width=35,borderwidth=4,show='*')
    password.place(x=200.,y=240)

def clicklogin(root,username,password):
    mycursor = mycon.cursor()
    print("username entered :",username.get())
    print("password entered :",password.get())
    pw = str(password.get())
    un = str(username.get())
    if len(pw) != 8 or pw == "        ":
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("Online Virtual Classes", "password must have 8 charecters")
    elif len(un) > 15 or len(un) < 4:
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("username error", "username should contain 4 charecters and not exceed 15 charecters")

    else:
        mycursor.execute("select * from tab1")
        result = mycursor.fetchall()
        for i in result:
            if i[0] == un and i[1]==pw:
                mn=i[2]
                mycon.commit()
                ii = Tk()
                ii.withdraw()
                messagebox.showinfo("Online Virtual Classes", "Account found")
                mode1.ask(root,un,mn)
                global l
                l="ok"
        if l!="ok":
            ii = Tk()
            ii.withdraw()
            messagebox.showerror("Online Virtual Classes", "Account not found")

def clickcre(root,username, password, mno):
    mycursor = mycon.cursor()
    pw = str(password.get())
    un = str(username.get())
    mn = str(mno.get())
    if len(pw) != 8 or pw == "        ":
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("Online Virtual Classes", "password must have 8 charecters")
    elif len(un) > 15 or len(un) < 4:
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("username error", "username should contain 4 charecters and not exceed 15 charecters")
    elif len(mn) != 10 or mn.isdigit() == False:
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("Online Virtual Classes", "INVALID MOBILE NUMBER")
    else:
        mycursor.execute("select * from tab1")
        result = mycursor.fetchall()
        for i in result:
            if i[2] == mn:
                ii = Tk()
                ii.withdraw()
                messagebox.showerror("Online Virtual Classes", "Mobile Number Already Exist")
                create(root)
            elif i[0] == un:
                ii = Tk()
                ii.withdraw()
                messagebox.showerror("Online Virtual Classes", "Enter different name")
                create(root)

        sql = "INSERT INTO tab1(username,password,mno) VALUES (%s,%s,%s)"
        val = (un, pw, mn)
        mycursor.execute(sql, val)
        mycon.commit()
        ii = Tk()
        ii.withdraw()
        messagebox.showinfo("Online Virtual Classes", "SUCESSFULLY record registered")
        mode1.ask(root,un,mn)'''

mod='''from tkinter import*
from pack import teacher,next,logcre

def donothing(root):
    root.destroy()

def student(root,un,mn):
    logcre.clear(root)

    label2=Label(root,text="Classroom Name : ",font=("arial",15))
    label2.place(x=20,y=200)
    entry1=Entry(root,bd=5,width=35)
    entry1.place(x=210,y=200)

    label3=Label(root,text="Enter Password   : ",font=("arial",15))
    label3.place(x=20,y=240)
    entry2=Entry(root,bd=5,width=35)
    entry2.place(x=210,y=240)

    enterbtn=Button(root,text="Next",padx=100,pady=20,bg="#ffb3fe",command=lambda :bcheck(root,entry1,entry2,un,mn))
    enterbtn.place(x=110,y=330)
    enterbtn1=Button(root,text="back",padx=10,pady=5,bg="#ffb3fe",command=lambda :ask(root,un,mn))
    enterbtn1.place(x=10,y=5)

def bcheck(root,entry1,entry2,un,mn):
    e1=str(entry1.get())
    e2=str(entry2.get())
    next.check(root,e1,e2,un,mn)

def ask(root,un,mn):
    logcre.clear(root)

    frame2=LabelFrame(root , borderwidth=0)
    frame2.pack(pady=50)
    mylab=Label(frame2,text='ENTER IN AS : ',font=("arial",18),fg="black")
    mylab.pack()

    frame=LabelFrame(root)
    frame.pack(pady=20)

    frame1=LabelFrame(root)
    frame1.pack()

    btn1=Button(frame,text="TEACHER",padx=130,pady=50,font=("arial",18),bg="sky blue",fg="black",command=lambda:teacher.main(root,un,mn))
    btn1.grid(row=0,column=0)
    btn2 = Button(frame1, text="STUDENT",padx=130,pady=50,font=("arial",18),bg="sky blue",fg="black",command=lambda:student(root,un,mn))
    btn2.grid(row=1, column=0)

    back1 = Button(root, text="HOME", padx=10, pady=5, bg="sky blue", command=lambda: logcre.home(root))
    back1.place(x=10, y=5)'''

nex='''from tkinter import *
from tkinter import ttk,messagebox
import mysql.connector as mysys
import webbrowser
import datetime
from pack import mode1,logcre,reason

mycon = mysys.Connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="classroom")
mycona = mysys.Connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="attendance")

l=""
p=""
def check(root,e1,e2,un,mn):
    global block
    block=""
    global p
    p=""
    mycursor = mycon.cursor()
    if len(e2) != 7 or e2 == "        ":
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("Online Virtual Classes", "password must have 7 charecters")
    elif len(e1) > 15 or len(e1) < 4:
        ii = Tk()
        ii.withdraw()
        messagebox.showerror("username error", "username should contain 4 charecters and not exceed 15 charecters")
    else:
        mycursor.execute("select * from clsinfo")
        result = mycursor.fetchall()
        for i in result:
            print(i)
            if i[0] == e1 and i[2]==e2:
                mycona = mysys.Connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="attendance")
                cursor = mycona.cursor()
                cursor.execute("select * from "+i[1])
                resu=cursor.fetchall()
                for rec in resu:
                    print(rec)
                    if rec[0]==mn:
                        mode1.student(root,un,mn)
                        messagebox.showwarning("Online Virtual Classes", "You were blocked")
                        mycona.commit()
                        block="yes"
        if block!="yes":
            for i in result:
                if i[0] == e1 and i[2] == e2 and block!="yes":
                    mycon.commit()
                    ii = Tk()
                    ii.withdraw()
                    messagebox.showinfo("Online Virtual Classes", "Connecting to classroom")
                    tname=str(i[1])
                    checkok(root,tname,un,mn)
                    mycon.commit()
        
def checkok(root,tname,un,mn):
    logcre.clear(root)
    mycon = mysys.Connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="classroom")
    cursor = mycon.cursor()
    q="select * from "+tname
    cursor.execute(q)
    i=0
    sum = Label(root, text="Classroom Timetable",font=("Helvetica",15))
    sum.place(x=130,y=6)
    frame = LabelFrame(root, borderwidth=5)
    frame.pack(padx=10, pady=50)
    for student in cursor:
        print(student)
        for j in range(2):
            name=student[0]
            bab = Button(frame, text=name, padx=30, pady=5, font=("Helvetica", 12),borderwidth=0,
                         command=lambda name=name: schedule(name,tname,un,mn))
            bab.grid(row=i + 1, column=0)
            lab=Label(frame,text=student[1],padx=30,pady=5,font=("Helvetica",12))
            lab.grid(row=i+1, column=1)
            lab1 = Label(frame, text=student[2], padx=30, pady=5, font=("Helvetica", 12))
            lab1.grid(row=i + 1, column=2)
        i=i+1
    def doSomething():
        print("closed")
    button = ttk.Button(root, text="Back", command=lambda :tryclose(root,un,mn,tname))
    button.place(x=0, y=0)
    root.protocol('WM_DELETE_WINDOW',lambda :tryclose(root,un,mn,tname))  # root is your root window

    mycon.commit()

def tryclose(root,un,mn,tname):
    global go
    go=""
    mycon = mysys.Connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="classroom")
    cursor = mycon.cursor()
    q="select * from "+tname
    cursor.execute(q)
    for student in cursor:
        print(student)
        sth=student[1][0:2]
        stm = student[1][3:5]
        eth = student[2][0:2]
        etm = student[2][3:5]

        ctn = datetime.datetime.now()
        ctn = ctn.strftime("%H:%M")

        now = str(ctn[0:2]) + "." + str(ctn[3:5])
        start = str(sth) + "." + str(stm)
        end = str(eth) + "." + str(etm)
        print((now,start,end))

        if float(now) >= float(start) and float(now) <= float(end) : #ctn>student[1] and ctn<student[2]
            reason.askreason(root,un,mn,tname)
            go="no"
    if go!="no":
        root.protocol('WM_DELETE_WINDOW', lambda :donothing(root))
        mode1.student(root,un,mn)

def donothing(root):
    root.destroy()

def schedule(subject,tname,un,mn):
    mycon = mysys.Connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="classroom")
    cursor = mycon.cursor()
    qu = "select * from " + tname
    cursor.execute(qu)
    for rec in cursor:
        print(rec)
        if subject == rec[0]:
            st=str(rec[1])
            et=str(rec[2])
            print(st)
            sth=int(st[0:2])
            stm=int(st[3:5])
            etm = int(et[3:5])
            eth=int(et[0:2])
            fa=str(rec[5])
            print(st,et,stm,etm)
            messagebox.showinfo("Online Virtual Classes", "LOADING....")
            loading(rec,sth,eth,stm,etm,fa,un,mn)
            break

def loading(rec,sth,eth,stm,etm,fa,un,mn):
    ct = datetime.datetime.now()
    ct = ct.strftime("%H:%M")
    print(ct[0:2])
    print("-------")
    print(sth,eth,stm,etm)
    print(ct[0:2],ct[3:5])

    now = str(ct[0:2])+"."+str(ct[3:5])
    start = str(sth)+"."+str(stm)
    end = str(eth)+"."+str(etm)

    #if ct[0:2] in t:
    if float(now) >= float(start) and float(now) <= float(end) : #and int(ct[3:5])>=stm and int(ct[3:5])<etm int(ct[0:2])>=sth and int(ct[0:2])<eth
        print("live")
        webbrowser.open_new(str(rec[3]))
        fattendance(fa,un,mn)
    else:
        print("rec")
        webbrowser.open_new(str(rec[4]))

def fattendance(fa,un,mn):
    ct = datetime.datetime.now()
    date = datetime.datetime.date(ct)
    cursor=mycona.cursor()
    q="insert into "+fa+"(date,username,mno) values (%s,%s,%s)"
    val=(date,un,mn)
    cursor.execute(q,val)
    mycona.commit()

def hattendance(ha,fa,un,mn,reason):
    ct = datetime.datetime.now()
    time = ct.strftime("%H:%M:%S")
    date = datetime.datetime.date(ct)
    cursor = mycona.cursor()
    q = "insert into " + ha + "(date,time,username,mno,reason) values (%s,%s,%s,%s)"
    val = (date,un, mn,reason)
    cursor.execute(q, val)
    mycona.commit()
'''


rea='''from tkinter import *
from tkinter import ttk
import time
from tkinter import messagebox
import webbrowser
import datetime
import mysql.connector as mysys
from pack import next,mode1,logcre

mycona = mysys.Connect(host="localhost", user="'''+name+'''", passwd="'''+p+'''", database="attendance")

def askreason(root,un,mn,tname):
    ha=tname+"ha"
    logcre.clear(root)

    subject1label = Label(root, text="Type your reason for leaving class:",anchor=NW).grid(row=1, column=1)
    reason = Entry(root, width="50")
    reason.grid(row=3, column=1,padx=60,pady=50,ipady=35)

    bt_1 = Button(root, text="Submit", padx=10, pady=5,font=("arial",12),bg="sky blue", command=lambda: hattendance(root, ha, un, mn, reason))
    bt_1.place(x=250, y=500)
    bt_2 = Button(root, text="Back to class", padx=20, pady=5, font=("arial", 12), bg="sky blue",
                  command=lambda: next.checkok(root,tname,un,mn))
    bt_2.place(x=80, y=500)

    hour = StringVar()
    minute = StringVar()
    second = StringVar()

    hour.set("00")
    minute.set("02")
    second.set("00")

    hourEntry = Entry(root, width=3, font=("Arial", 18, ""),
                  textvariable=hour)
    hourEntry.place(x=80, y=300)

    minuteEntry = Entry(root, width=3, font=("Arial", 18, ""),
                    textvariable=minute)
    minuteEntry.place(x=130, y=300)

    secondEntry = Entry(root, width=3, font=("Arial", 18, ""),
                    textvariable=second)
    secondEntry.place(x=180, y=300)


    temp = int(hour.get()) * 3600 + int(minute.get()) * 60 + int(second.get())

    while temp > -1:
        mins, secs = divmod(temp, 60)
        hours = 0
        if mins > 60:
            hours, mins = divmod(mins, 60)

        hour.set("{0:2d}".format(hours))
        minute.set("{0:2d}".format(mins))
        second.set("{0:2d}".format(secs))
        try:
            root.update()
        except:
            pass

        time.sleep(1)

        if (temp == 0):
            messagebox.showinfo("Time Countdown", "Time's up ")
            next.checkok(root,tname,un,mn)

        temp -= 1


def hattendance(root,ha,un,mn,reason):
    reason=reason.get()
    ct = datetime.datetime.now()
    time = ct.strftime("%H:%M:%S")
    date = datetime.datetime.date(ct)
    cursor = mycona.cursor()
    q = "insert into " + ha + "(date,time,username,mno,reason) values (%s,%s,%s,%s,%s)"
    val = (date,time,un, mn,reason)
    cursor.execute(q, val)
    mycona.commit()
    messagebox.showinfo("Online Virtual Classes","Reason sent to teacher")
    root.protocol('WM_DELETE_WINDOW', lambda: next.donothing(root))
    mode1.student(root,un,mn)



'''


tea='''from tkinter import *
from PIL import ImageTk , Image
from pack import classroom,mode1,editcls,logcre
root=0
no = 0
uun=0
mmn=0
def wallpaper(pa):
    img = ImageTk.PhotoImage(Image.open("ll.jpg"))
    bglabel = Label(pa, image=img)
    bglabel.place(x=0, y=0)
    return

def back(root):
    main(root,uun,mmn)

def main(root,un,mn):
    logcre.clear(root)
    #wallpaper(root)
    global uun,mmn
    uun=un
    mmn=mn
    button1=Button(root,text="Create Classroom",padx=50,pady=50,font=("arial",12),bg="sky blue",fg="black",command=lambda:create(root))
    button1.place(x=110,y=30)
    button2=Button(root,text="Edit Classroom",padx=60,pady=50,font=("arial",12),fg="black",bg="sky blue",command=lambda :editcls.edit(root))
    button2.place(x=110,y=190)
    button3=Button(root,text="Delete Classroom",padx=50,pady=50,font=("arial",12),bg="sky blue",fg="black",command=lambda :delete(root))
    button3.place(x=110,y=345)
    button4=Button(root,text="Enter Classroom",padx=150,pady=30,font=("arial",12),bg="sky blue",fg="black",command=lambda :student(root))
    button4.place(x=12,y=497)
    bac=Button(root,text="Back",padx=8,pady=2,font=("arial",12),bg="sky blue",command=lambda :mode1.ask(root,un,mn))
    bac.place(x=10,y=5)
    root.mainloop()

def student(root):
    logcre.clear(root)
    #wallpaper(sturoot)
    img = ImageTk.PhotoImage(Image.open("ll.jpg"))
    bglabel = Label(root, image=img)
    bglabel.place(x=0, y=0)

    label2=Label(root,text="Classroom Name : ",font=("arial",15))
    label2.place(x=20,y=200)
    entry1=Entry(root,bd=5,width=35)
    entry1.place(x=210,y=200)

    label3=Label(root,text="Enter Password   : ",font=("arial",15))
    label3.place(x=20,y=240)
    entry2=Entry(root,bd=5,width=35)
    entry2.place(x=210,y=240)

    enterbtn=Button(root,text="Next",padx=100,pady=20,bg="#ffb3fe",command=lambda :editcls.check(root,entry1,entry2))
    enterbtn.place(x=110,y=330)
    babtn=Button(root,text="Back",padx=10,pady=5,bg="#ffb3fe",command=lambda :back(root))
    babtn.place(x=8,y=4)

def create(root):
    logcre.clear(root)

    label2=Label(root,text="Classroom Name",font=("arial",15))
    label2.place(x=20,y=180)
    entry1=Entry(root,bd=5,width=35)
    entry1.place(x=210,y=180)

    label3=Label(root,text="Teacher's Password",font=("arial",15))
    label3.place(x=18,y=220)
    entry2=Entry(root,bd=5,width=35)
    entry2.place(x=210,y=220)

    label4=Label(root,text="Student Password",font=("arial",15))
    label4.place(x=20,y=260)
    entry3=Entry(root,bd=5,width=35)
    entry3.place(x=210,y=260)

    ok=Button(root,text="Next",padx=30,pady=5,borderwidth=4,font=("arial",12),bg="sky blue",command=lambda :classroom.clsreg(entry1,entry2,entry3,root))
    ok.place(x=300,y=350)
    ba=Button(root,text="back",padx=10,pady=5,font=("arial",12),bg="sky blue",command=lambda :back(root))
    ba.place(x=10,y=5)

    def okbtn():
        e1=str(entry1.get())
        e2=str(entry2.get())
        e3=str(entry3.get())
        classroom.clsreg(e1,e2,e3,root)

def delete(root):
    logcre.clear(root)

    label21=Label(root,text="Classroom Name",font=("arial",15))
    label21.place(x=20,y=200)
    entry11=Entry(root,bd=5,width=35)
    entry11.place(x=210,y=200)

    label32=Label(root,text="Teacher's Password",font=("arial",15))
    label32.place(x=18,y=240)
    entry22=Entry(root,bd=5,width=35)
    entry22.place(x=210,y=240)

    okb=Button(root,text="Delete",padx=100,pady=15,bg="#ffb3fe",command=lambda :okbF())
    okb.place(x=100,y=500)

    back1=Button(root,text="Back",padx=10,pady=5,bg="#ffb3fe",command=lambda :back(root))
    back1.place(x=10,y=5)

    def okbF():
        e11=str(entry11.get())
        e22=str(entry22.get())
        classroom.clsdel(e11,e22)
'''

os.makedirs("virtual_class/pack")

with open(str(folder)+"/vc.py", "w") as f:
    f.write(vc)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
with open("virtual_class/pack/classroom.py", "w") as f:
    f.write(cs)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
with open("virtual_class/pack/editcls.py", "w") as f:
    f.write(ed)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
with open("virtual_class/pack/forgot.py", "w") as f:
    f.write(fo)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
with open("virtual_class/pack/logcre.py", "w") as f:
    f.write(log)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
with open("virtual_class/pack/mode1.py", "w") as f:
    f.write(mod)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
with open("virtual_class/pack/next.py", "w") as f:
    f.write(nex)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
with open("virtual_class/pack/reason.py", "w") as f:
    f.write(rea)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
with open("virtual_class/pack/teacher.py", "w") as f:
    f.write(tea)  # TODO: CHECK IF NEW LINE CHARACTER IS NEEDED OR NOT
    f.close()
    
